def welcome_user():
    name = input('May I have your name? ')
    print("Hello, " + name + "!")

if __name__ == '__main__':
    welcome_user()
    